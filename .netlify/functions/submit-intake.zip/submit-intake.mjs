
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/submit-intake.mjs
var SUPABASE_URL = "https://vzxvilqixewowiqmltcu.supabase.co";
var SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZ6eHZpbHFpeGV3b3dpcW1sdGN1Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3MjA0ODg0OSwiZXhwIjoyMDg3NjI0ODQ5fQ.uEH1Aqpfv8GqIWDGZEFuwp-PUfmp_IArACdBkto5YNQ";
var TG_BOT_TOKEN = "8529901915:AAGGKx4G0ApMk8YaMOOalyPgQmD6Wl-frR0";
var TG_CHAT_ID = "8235099154";
var submit_intake_default = async (req) => {
  const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "Content-Type", "Access-Control-Allow-Methods": "POST, OPTIONS" };
  if (req.method === "OPTIONS") return new Response("", { headers: cors });
  if (req.method !== "POST") return Response.json({ error: "Method not allowed" }, { status: 405 });
  try {
    const data = await req.json();
    const id = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    let supps = [];
    let skincare = [];
    try {
      supps = JSON.parse(data["supplements-data"] || "[]");
    } catch {
    }
    try {
      skincare = JSON.parse(data["skincare-data"] || "[]");
    } catch {
    }
    const row = {
      id,
      name: data.name || null,
      email: data.email || null,
      age: data.age || null,
      sex: data.sex || null,
      audit_type: data["audit-type"] || null,
      supplements_data: supps.length ? supps : null,
      skincare_data: skincare.length ? skincare : null,
      medications: data.medications || null,
      health_goals: data["health-goals"] || null,
      conditions: data.conditions || null,
      skin_type: data["skin-type"] || null,
      skin_concerns: data["skin-concerns"] || null,
      raw_payload: data
    };
    const dbRes = await fetch(`${SUPABASE_URL}/rest/v1/intake_submissions`, {
      method: "POST",
      headers: {
        "apikey": SUPABASE_KEY,
        "Authorization": `Bearer ${SUPABASE_KEY}`,
        "Content-Type": "application/json",
        "Prefer": "return=minimal"
      },
      body: JSON.stringify(row)
    });
    if (!dbRes.ok) {
      const err = await dbRes.text();
      console.error("Supabase error:", err);
    }
    const suppList = supps.map((s) => `  \u2022 ${s.name || "?"}${s.dose ? " \u2014 " + s.dose : ""}${s.frequency ? " (" + s.frequency + ")" : ""}`).join("\n");
    const msg = [
      `\u{1F514} *NEW INTAKE SUBMISSION*`,
      ``,
      `*Name:* ${data.name || "\u2014"}`,
      `*Email:* ${data.email || "\u2014"}`,
      `*Age:* ${data.age || "\u2014"} | *Sex:* ${data.sex || "\u2014"}`,
      `*Audit:* ${data["audit-type"] || "\u2014"}`,
      supps.length ? `
*Supplements:*
${suppList}` : "",
      data.medications ? `*Medications:* ${data.medications}` : "",
      data["health-goals"] ? `*Goals:* ${data["health-goals"]}` : "",
      data.conditions ? `*Conditions:* ${data.conditions}` : "",
      `
_${(/* @__PURE__ */ new Date()).toLocaleString("en-US", { timeZone: "America/Los_Angeles" })}_`
    ].filter(Boolean).join("\n");
    await fetch(`https://api.telegram.org/bot${TG_BOT_TOKEN}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: TG_CHAT_ID, text: msg, parse_mode: "Markdown" })
    }).catch((err) => console.error("TG error:", err));
    console.log("SUBMISSION:" + JSON.stringify({ id, name: data.name, email: data.email, audit: data["audit-type"] }));
    return Response.json({ success: true, id }, { headers: cors });
  } catch (err) {
    console.error("Error:", err);
    return Response.json({ error: "Failed to save" }, { status: 500, headers: cors });
  }
};
var config = { path: "/api/submit-intake" };
export {
  config,
  submit_intake_default as default
};
