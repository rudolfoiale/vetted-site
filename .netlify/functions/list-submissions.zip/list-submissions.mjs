
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/list-submissions.mjs
import { getStore } from "@netlify/blobs";
var list_submissions_default = async (req) => {
  const url = new URL(req.url);
  const key = url.searchParams.get("key");
  const token = "nfp_5toB";
  if (key !== token) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }
  const store = getStore("intake-submissions");
  try {
    const index = await store.get("_index", { type: "json" });
    return Response.json({ submissions: index || [] });
  } catch {
    return Response.json({ submissions: [] });
  }
};
var config = {
  path: "/api/list-submissions"
};
export {
  config,
  list_submissions_default as default
};
